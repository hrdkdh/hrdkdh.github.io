@echo off
REM 배치 파일(cmd)에서는 %USERPROFILE%을 사용합니다.
PowerShell -NoProfile -ExecutionPolicy Bypass -Command "& '%USERPROFILE%\Desktop\VDI\MySetting.ps1'"