# MySetting.ps1

# 1. 작업 표시줄 설정 (단추 하나로 표시 안 함 = 2)
Write-Host "1. 작업 표시줄 설정을 변경합니다..."
$regPath = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced"
Set-ItemProperty -Path $regPath -Name "TaskbarGlomLevel" -Value 2

# 탐색기 재시작
Stop-Process -Name explorer -Force
Start-Sleep -Seconds 2

# 2. Office 빠른 실행 도구 모음 복원
Write-Host "2. Office 설정을 복원합니다..."

$sourcePath = "$env:USERPROFILE\Desktop\VDI"
$destPath = "$env:LOCALAPPDATA\Microsoft\Office"

# 폴더가 없으면 생성
if (!(Test-Path $destPath)) { New-Item -ItemType Directory -Path $destPath -Force }

# 설정 파일 덮어쓰기 (파일이 실제로 존재하는지 확인 후 복사)
if (Test-Path "$sourcePath\Excel.officeUI") {
    Copy-Item -Path "$sourcePath\Excel.officeUI" -Destination $destPath -Force
} else {
    Write-Host "경고: 엑셀 설정 파일을 찾을 수 없습니다."
}

if (Test-Path "$sourcePath\PowerPoint.officeUI") {
    Copy-Item -Path "$sourcePath\PowerPoint.officeUI" -Destination $destPath -Force
} else {
    Write-Host "경고: 파워포인트 설정 파일을 찾을 수 없습니다."
}

# 3. MS Teams 로그인 자동화
Write-Host "3. MS Teams 로그인을 시도합니다..."

$teamsPath = "$env:LOCALAPPDATA\Microsoft\Teams\current\Teams.exe"
if (Test-Path $teamsPath) {
    Start-Process $teamsPath
    Start-Sleep -Seconds 10 
    
    Add-Type -AssemblyName System.Windows.Forms
    
    # 아이디 미리입력
    [System.Windows.Forms.SendKeys]::SendWait("hrdkdh@poscohrd.com") 
    Start-Sleep -Milliseconds 500
    [System.Windows.Forms.SendKeys]::SendWait("{ENTER}")
    
    Start-Sleep -Seconds 5 
    
} else {
    Write-Host "Teams 실행 파일을 찾을 수 없습니다."
}

Write-Host "설정 완료! 창을 닫습니다."
Start-Sleep -Seconds 2