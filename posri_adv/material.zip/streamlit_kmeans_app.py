
# streamlit_kmeans_app.py
# Run with: streamlit run streamlit_kmeans_app.py
# Requirements: streamlit, scikit-learn, pandas, matplotlib

import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import streamlit as st
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans

st.set_page_config(page_title="Mall Customers Clustering (k=5)", layout="wide")

st.title("Mall Customers Clustering — 5 Clusters (Income & Spending)")

with st.expander("About this app"):
    st.write(
        """
        This app loads the classic **Mall Customers** dataset and performs **K-Means clustering** with **k=5**
        using two features:
        - Annual Income (k$)
        - Spending Score (1-100)

        Use the sliders in the sidebar to choose an **Annual Income** and **Spending Score**;
        the app will predict your point's cluster and plot it on the scatter chart.
        """
    )

@st.cache_data
def load_data(default_path: str = "customers_mall.csv") -> pd.DataFrame:
    # Try to load from current directory; fall back to sample if not found
    if os.path.exists(default_path):
        return pd.read_csv(default_path)
    # If not found, prompt user to upload
    return pd.DataFrame()

uploaded = st.sidebar.file_uploader("Upload customers_mall.csv (optional)", type=["csv"])
if uploaded is not None:
    df = pd.read_csv(uploaded)
else:
    df = load_data()

if df.empty:
    st.warning("No data loaded. Please upload **customers_mall.csv** using the sidebar.")
    st.stop()

# Ensure required columns exist
required_cols = ["Annual Income (k$)", "Spending Score (1-100)"]
missing = [c for c in required_cols if c not in df.columns]
if missing:
    st.error(f"Missing required columns: {missing}. Upload a CSV with these columns.")
    st.stop()

# Select features
X = df[["Annual Income (k$)", "Spending Score (1-100)"]].copy()

# Sidebar sliders based on data range
income_min, income_max = int(np.floor(X["Annual Income (k$)"].min())), int(np.ceil(X["Annual Income (k$)"].max()))
score_min, score_max = int(np.floor(X["Spending Score (1-100)"].min())), int(np.ceil(X["Spending Score (1-100)"].max()))

st.sidebar.header("Pick a point to classify")
user_income = st.sidebar.slider("Annual Income (k$)", income_min, income_max, int(np.median(X["Annual Income (k$)"])))
user_score = st.sidebar.slider("Spending Score (1-100)", score_min, score_max, int(np.median(X["Spending Score (1-100)"])))

# Scale and fit KMeans (k=5)
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X.values)

kmeans = KMeans(n_clusters=5, random_state=42, n_init=10)
labels = kmeans.fit_predict(X_scaled)

# Add labels back to df
df["cluster"] = labels

# Predict user point cluster
user_point_scaled = scaler.transform(np.array([[user_income, user_score]]))
user_cluster = int(kmeans.predict(user_point_scaled)[0])

# Get centroids in original scale for plotting
centroids_scaled = kmeans.cluster_centers_
centroids = scaler.inverse_transform(centroids_scaled)

# Layout
left, right = st.columns([2, 1])

with left:
    st.subheader("Clusters Scatter Plot")
    fig, ax = plt.subplots(figsize=(8, 6))
    # Plot each cluster
    for c in sorted(df["cluster"].unique()):
        subset = df[df["cluster"] == c]
        ax.scatter(
            subset["Annual Income (k$)"],
            subset["Spending Score (1-100)"],
            s=40, alpha=0.7, label=f"Cluster {c}"
        )

    # Plot centroids
    ax.scatter(centroids[:, 0], centroids[:, 1], s=160, marker="D", edgecolors="black", linewidths=1.2, label="Centroids")

    # Plot user point
    ax.scatter([user_income], [user_score], s=160, marker="X", edgecolors="black", linewidths=1.2, label="Your point")

    ax.set_xlabel("Annual Income (k$)")
    ax.set_ylabel("Spending Score (1-100)")
    ax.set_title("K-Means (k=5) — Income vs. Spending")
    ax.legend(loc="best")
    st.pyplot(fig, clear_figure=True)

with right:
    st.subheader("Prediction")
    st.metric("Predicted Cluster", f"{user_cluster}")
    st.write("Your chosen point:")
    st.write(f"- Annual Income (k$): **{user_income}**")
    st.write(f"- Spending Score (1-100): **{user_score}**")

    st.subheader("Cluster Centroids (original scale)")
    cent_df = pd.DataFrame(centroids, columns=["Annual Income (k$)", "Spending Score (1-100)"])
    cent_df.index.name = "cluster"
    st.dataframe(cent_df.style.format({"Annual Income (k$)": "{:.1f}", "Spending Score (1-100)": "{:.1f}"}))

st.caption("Tip: place the CSV file in the same folder as this script and name it **customers_mall.csv**, or upload it via the sidebar.")
