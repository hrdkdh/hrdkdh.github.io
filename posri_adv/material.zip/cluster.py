
# cluster.py
# Run with: streamlit run cluster.py
# Requirements: streamlit, scikit-learn, pandas, matplotlib

import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import streamlit as st
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans

st.set_page_config(page_title="Customer Clustering (k=5)", layout="wide")
st.title("Customer Clustering — Income vs. Spending (k=5)")

with st.expander("사용 방법"):
    st.markdown(
        """
        - 왼쪽 사이드바에서 **Annual Income (k$)**, **Spending Score (1-100)** 값을 선택하세요.  
        - 데이터는 현재 폴더의 `customers_mall.csv`를 자동으로 읽거나, 사이드바에서 업로드할 수 있습니다.  
        - k-means (k=5) 클러스터링 결과 산점도와 **선택한 점의 위치/군집**을 확인할 수 있습니다.
        """
    )

@st.cache_data
def load_data(default_path: str = "customers_mall.csv") -> pd.DataFrame:
    if os.path.exists(default_path):
        return pd.read_csv(default_path)
    return pd.DataFrame()

uploaded = st.sidebar.file_uploader("customers_mall.csv 업로드(선택)", type=["csv"])
if uploaded is not None:
    df = pd.read_csv(uploaded)
else:
    df = load_data()

if df.empty:
    st.warning("데이터가 없습니다. `customers_mall.csv`를 동일 폴더에 두거나, 왼쪽에서 업로드하세요.")
    st.stop()

required_cols = ["Annual Income (k$)", "Spending Score (1-100)"]
missing = [c for c in required_cols if c not in df.columns]
if missing:
    st.error(f"필수 컬럼이 없습니다: {missing}. 해당 컬럼이 포함된 CSV를 업로드하세요.")
    st.stop()

# --- Feature selection ---
X = df[["Annual Income (k$)", "Spending Score (1-100)"]].copy()

# --- Sidebar controls ---
income_min, income_max = int(np.floor(X["Annual Income (k$)"].min())), int(np.ceil(X["Annual Income (k$)"].max()))
score_min, score_max = int(np.floor(X["Spending Score (1-100)"].min())), int(np.ceil(X["Spending Score (1-100)"].max()))

st.sidebar.header("분류할 점 선택")
user_income = st.sidebar.slider("Annual Income (k$)", min_value=income_min, max_value=income_max, value=int(np.median(X["Annual Income (k$)"])))
user_score = st.sidebar.slider("Spending Score (1-100)", min_value=score_min, max_value=score_max, value=int(np.median(X["Spending Score (1-100)"])))

# --- Scaling & KMeans ---
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X.values)

kmeans = KMeans(n_clusters=5, random_state=42, n_init=10)
labels = kmeans.fit_predict(X_scaled)
df["cluster"] = labels

# --- Predict user point cluster ---
user_scaled = scaler.transform(np.array([[user_income, user_score]]))
user_cluster = int(kmeans.predict(user_scaled)[0])

# --- Centroids in original scale ---
centroids = scaler.inverse_transform(kmeans.cluster_centers_)

# --- Layout ---
left, right = st.columns([2, 1])

with left:
    st.subheader("산점도")
    fig, ax = plt.subplots(figsize=(8, 6))
    for c in sorted(df["cluster"].unique()):
        subset = df[df["cluster"] == c]
        ax.scatter(
            subset["Annual Income (k$)"],
            subset["Spending Score (1-100)"],
            s=40, alpha=0.7, label=f"Cluster {c}"
        )
    # centroids
    ax.scatter(centroids[:, 0], centroids[:, 1], s=160, marker="D", edgecolors="black", linewidths=1.2, label="Centroids")
    # user point
    ax.scatter([user_income], [user_score], s=160, marker="X", edgecolors="black", linewidths=1.2, label="Your point")

    ax.set_xlabel("Annual Income (k$)")
    ax.set_ylabel("Spending Score (1-100)")
    ax.set_title("K-Means (k=5) — Income vs. Spending")
    ax.legend(loc="best")
    st.pyplot(fig, clear_figure=True)

with right:
    st.subheader("예측 결과")
    st.metric("Predicted Cluster", f"{user_cluster}")
    st.write("- Annual Income (k$): **{}**".format(user_income))
    st.write("- Spending Score (1-100): **{}**".format(user_score))

    st.subheader("클러스터 중심(원 스케일)")
    cent_df = pd.DataFrame(centroids, columns=["Annual Income (k$)", "Spending Score (1-100)"])
    cent_df.index.name = "cluster"
    st.dataframe(cent_df.style.format({"Annual Income (k$)": "{:.1f}", "Spending Score (1-100)": "{:.1f}"}))

st.caption("Tip: `customers_mall.csv`를 스크립트와 같은 폴더에 두면 자동으로 로드됩니다. 파일 이름을 그대로 사용하세요.")
