import streamlit as st
import koreanize_matplotlib
import matplotlib.pyplot as plt

# 회귀계수 및 절편
intercept = -123.13
coef_필터차압 = -0.27
coef_날개개도 = 0.46
coef_흡입유량 = 0.79

st.title("🔧 발전기 복합출력 예측기")

st.markdown("독립변수를 조정하면 복합출력이 어떻게 달라지는지 확인할 수 있습니다.")

# 좌우 컬럼 배치
left_col, right_col = st.columns(2)

with left_col:
    st.header("🔧 입력값 설정")
    필터차압 = st.slider("전체필터차압", min_value=3.0, max_value=8.0, step=0.1, value=5.5)
    날개개도 = st.slider("공기압축기날개개도", min_value=50.0, max_value=90.0, step=0.5, value=70.0)
    흡입유량 = st.slider("공기압축기흡입유량", min_value=400.0, max_value=600.0, step=1.0, value=500.0)

# 예측 복합출력 계산
복합출력 = intercept + coef_필터차압 * 필터차압 + coef_날개개도 * 날개개도 + coef_흡입유량 * 흡입유량

with right_col:
    st.header("📈 예측 결과")
    st.subheader(f"복합출력: **{복합출력:.2f} MW**")

    fig, ax = plt.subplots(figsize=(4, 5))
    ax.bar(["복합출력"], [복합출력], color="skyblue")
    ax.set_ylim(200, 400)
    ax.set_ylabel("출력 (MW)")
    ax.set_title("예측 복합출력")
    st.pyplot(fig)
